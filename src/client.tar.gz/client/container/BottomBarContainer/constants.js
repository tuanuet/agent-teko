export const FETCH_META = 'app/BottomBarContainer/FETCH_META';
export const FETCH_META_SUCCESS = 'app/BottomBarContainer/FETCH_META_SUCCESS';
export const FETCH_META_FAILURE = 'app/BottomBarContainer/FETCH_META_FAILURE';

export const UPLOAD_IMAGE ='app/BottomBarContainer/UPLOAD_IMAGE';
export const UPLOAD_IMAGE_SUCCESS ='app/BottomBarContainer/UPLOAD_IMAGE_SUCCESS';
export const UPLOAD_IMAGE_FAILURE ='app/BottomBarContainer/UPLOAD_IMAGE_FAILURE';
export const DEFAULT = 100;
export const NOTIFICATION = 101;
export const RATING = 102;
export const IMAGE = 103;
